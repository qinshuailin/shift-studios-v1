import Foundation

enum NotificationType {
    case success
    case warning
    case error
}
