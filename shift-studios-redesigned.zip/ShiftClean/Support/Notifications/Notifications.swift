import Foundation

extension Notification.Name {
    // Define the notification name as a static constant
    static let focusModeToggled = Notification.Name("com.shiftstudios.ShiftClean.focusModeToggled")
}
